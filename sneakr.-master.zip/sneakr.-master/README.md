# sneakr. online shop

### React project for an e-commerce online sneaker shop

##### Technologies used: React.js/Node.js/SCSS

##### Component diagram including the main components
![sneakr_component-diagram](https://user-images.githubusercontent.com/65340138/91661475-9ca53980-eadc-11ea-8871-8bab465361b6.png)

##### Or try sneakr. for yourself
[GitHub Pages](https://Taha899.github.io/taha-shoe./)
